export interface DialogData {
  title: string;
  message: string;
}
