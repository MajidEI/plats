// model dial plat
export interface Client {
  id: number;
  nom: string;
  categorie: string;
  prix: string;
  description: string;
  image: string;
}

